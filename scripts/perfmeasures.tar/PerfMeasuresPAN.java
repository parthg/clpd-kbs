package evaluation;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.SAXException;

import common.Com;
import common.Configuration;

import documents.AnnDocument.Annotation;
import documents.DetectionDocument;
import documents.SuspiciousDocument;
import documents.SuspiciousDocument.SuspiciousAnnotation;
import es.nlel.common.io.FileIO;
import es.nlel.common.report.Reporter;
import es.nlel.pan.xml.DetectionXMLreader;
import es.nlel.pan.xml.SuspiciousXMLreader;

/**
 * Plagiarism detection performance measures.
 * 
 * This program is based on perfmeasures.py, developed by Martin Potthast.
 * It implements measures macro average recall and granularity as 
 * described by the authors of [1]. 
 * 
 * The main difference to the Python implementations is that the Recall 
 * can be obtained for every case instead of only the global result (only
 * small modifications were required to get this values with the Python
 * implementation, but we decided to make a version in Java).
 * [1]  Martin Potthast, Benno Stein, Alberto Barron-Cedeno, and Paolo Rosso.
 *      An Evaluation Framework for Plagiarism Detection.
 *      In Proceedings of the 23rd International Conference on Computational
 *      Linguistics (COLING 2010), Beijing, China. August 2010. ACL.
 *      
 * @author albarron
 *
 */
public class PerfMeasuresPAN extends PerfMeasures{

	
	
	
	//Controllers
	private int counter;
	
	//local variables that are used in different methods
	private int offset_difference;
	private int overlap_start;
	private int overlap_end;
	private boolean fragment_detected;

	/**
	 * Initialises the object by considering
	 * every plagiarised fragment relevant.
	 */
	public PerfMeasuresPAN(){
		this(false, false, false, false, false);			
	}
	
	/**
	 * Loads the Suspicious and Detection readers and 
	 * define what cases are interesting for analysis.
	 * @param onlySimulated
	 * @param onlyArtificial
	 * @param onlyCrossLanguage
	 * @param onlyExternal
	 * @param onlyIntrinsic
	 */
	public PerfMeasuresPAN(boolean onlySimulated,
							    boolean onlyArtificial,
								boolean onlyCrossLanguage,
								boolean onlyExternal,
								boolean onlyIntrinsic){
//		this.simulated     = onlySimulated;
//		this.onlyArtificial    = onlyArtificial;
//		this.onlyCrossLanguage = onlyCrossLanguage;
//		this.onlyExternal      = onlyExternal;
//		this.onlyIntrinsic     = onlyIntrinsic;
		sReader = new SuspiciousXMLreader();
		dReader = new DetectionXMLreader();
	}
	
//	/**
//	 * Gets the list of suspicious annotations.
//	 * @return
//	 */
//	public List<Annotation> get_suspicious_list(){
//		return cases;
//	}
//	
//	/**
//	 * Gets the list of detection annotations.
//	 * @return
//	 */
//	public List<Annotation> get_detection_list(){
//		return detections;
//	}
//	
//	
//	/**
//	 * Charges the plagiarised fragment parameters into the global
//	 * variable atts:
//	 * 
//	 * - plagiarism_reference
//	 * - this_offset
//	 * - this_length
//	 * 
//	 * @param ann
//	 * @param id
//	 */
//	protected void chargetAttributesPlag (SuspiciousAnnotation ann, String id){
//		atts.clear();
//		//Suspicious fragment
//		atts.addAttribute("","","plagiarism_reference", "CDATA", id);
//		atts.addAttribute("","","this_offset", "CDATA", String.valueOf(ann.this_offset)); 
//		atts.addAttribute("","","this_length", "CDATA", String.valueOf(ann.this_length));
//				
//		//Source fragment
//		atts.addAttribute("","","source_reference", "CDATA", ann.source_reference);
//		atts.addAttribute("","","this_offset", "CDATA", String.valueOf(ann.source_offset)); 
//		atts.addAttribute("","","this_length", "CDATA", String.valueOf(ann.source_length));				
//	}
//	
//	/**
//	 * Iterates over the XML suspicious files in a 
//	 * directory to load the annotations.
//	 * 
//	 * @throws ParserConfigurationException
//	 * @throws SAXException
//	 * @throws IOException
//	 */
//	public void extract_annotations_suspicious() 
//		throws ParserConfigurationException, SAXException, IOException{
//		counter = 1;	
//		List<String> xmlFiles = FileIO.getSpecificFilesRecursively(
//				new File(ann_path), "suspicious", "xml");
//				
//		for (String f : xmlFiles){
//			Reporter.reportIfModule(("Extracting plagiairsm cases from " + counter), counter++, report_control);
//			update_suspicious((SuspiciousDocument) sReader.xml2AnnDoc(f));
//		}		
//		case_index = index_annotations(cases);		
//		Reporter.report("Plagiarism cases extracted: " + cases.size());
//	}	
//	
//	/**
//	 * If requested, keeps only a kind of plagiarism from the
//	 * suspicious documents annotations: 
//	 * intrinsic, external, artificial, simulated, cross.
//	 * 
//	 * @param sDocument
//	 */
//	private void update_suspicious(SuspiciousDocument sDocument){
//		if (sDocument.contains_plagiarism == 0)	//the document does not contain plagiarism.
//			return;
//		
//		if (onlyIntrinsic)
//			sDocument.keepOnlyIntrinsic();
//		else if (onlyExternal)
//			sDocument.keepOnlyExternal();
//		else if (simulated)
//			sDocument.keepOnlySimulated();
//		else if (onlyArtificial)
//			sDocument.keepOnlyArtificial();
//		else if (onlyCrossLanguage)
//			sDocument.keepOnlyCrossLanguage();
//
//		if (sDocument.susp_annotations.size() > 0)
//			cases.addAll(sDocument.susp_annotations);				
//	}
//	
//	/**
//	 * Iterates over the XML detection files in a 
//	 * directory to import the annotations.
//	 * 
//	 * @throws ParserConfigurationException
//	 * @throws SAXException
//	 * @throws IOException
//	 */
//	public void extract_annotations_detection() 
//		throws ParserConfigurationException, SAXException, IOException{
//		counter = 1;	
//		List<String> xmlFiles = FileIO.getSpecificFilesRecursively(
//				new File(det_path), "suspicious", "xml");
//		
//		for (String f : xmlFiles){
//			Reporter.reportIfModule(("Extracting detections from file " + counter), 
//								counter++, report_control);			
//			update_detection((DetectionDocument) dReader.xml2AnnDoc(f));
//		}
//		det_index = new	HashMap<String, List<Annotation>>();	//	CREO QUE AQUI ESTA EL ERROR 
//		det_index  = index_annotations(detections);		
//		Reporter.report("Detections extracted: " + detections.size());
//	}
//	
//	/**
//	 * Adds the new detections of this document information to the 
//	 * collection of detections
//	 * @param dDocument
//	 */
//	private void update_detection(DetectionDocument dDocument){
//		if (dDocument.annotations.size() > 0)
//			detections.addAll(dDocument.annotations);
//	}
//	
//	/**
//	 * Granularity of the detections
//	 * @return
//	 */
//	public double granularity(){
//		if (detections.size() == 0)
//	        return 1;
//		
//		double num_dets = 0;
//		double detected_cases = 0;
//		counter = 1;
//		
//		//pending determine whether some of this should be taken
//		//to another method in a way that it could be called 
//		//from outside to get the granularity per case.
//		detections_per_case.clear();
//		for (String susp_reference : case_index.keySet()){
//			Reporter.reportIfModule(("Recall for case " + counter), counter++, report_control);
//			if (! det_index.containsKey(susp_reference))
//				continue;
//			List<Annotation> this_detections = det_index.get(susp_reference);
//			
//			for (Annotation eCase : case_index.get(susp_reference)){
//				num_dets = 0;
//				for (Annotation det : this_detections)
//					if (is_overlapping(eCase, det))			num_dets++;						
//				detections_per_case.add(num_dets);
//			}			
//		}
//		
//		for (Double n_dets : detections_per_case)			
//			if (n_dets > 0)				detected_cases ++;			
//			
//		if (detected_cases == 0)
//	        return 1;
//	    return Com.sumList(detections_per_case) / detected_cases;	    
//	}
//	
//	/**
//	 * Macro average recall for the detections.
//	 * 
//	 * @return
//	 */
//	public double macro_avg_recall(){		
//		int num_cases = cases.size();
//		counter = 1;
//		
//		List<Double> recall_per_case = new ArrayList<Double>();
//		for (String susp_reference : case_index.keySet()){
////			Reporter.reportIf("Recall for case " + counter, counter++, 2);
//
//			if (! det_index.containsKey(susp_reference))
//				continue;
//			for (Annotation case_ann : case_index.get(susp_reference))
//				 recall_per_case.add( case_recall(case_ann, detections) );						
//		}
//		return Com.sumList(recall_per_case) / num_cases;
//	}	
//	
//	/**
//	 * Calculates recall for a given suspicious text fragment and the 
//	 * corresponding detections.
//	 *  
//	 * @param suspicious
//	 * @param detections
//	 * @return
//	 */
//	public double case_recall(Annotation suspicious, List<Annotation> detections){
//		double num_detected_plagiarized = overlapping_chars(suspicious, detections);
//		double num_plagiarized = suspicious.this_length + suspicious.source_length;
//		return num_detected_plagiarized / num_plagiarized;		
//	}
//	
//	/**
//	 * Returns the number of characters in ann1 that overlaps with
//	 * the annotation sin the detections list.
//	 * 
//	 * @param ann1
//	 * @param detections
//	 * @return
//	 */
//	private int overlapping_chars(Annotation ann1, List<Annotation> detections){		
//		List<Annotation> annotations = new ArrayList<Annotation>();
//
//		for (Annotation ann2 : detections)
//			if (is_overlapping(ann1, ann2))
//				annotations.add(ann2);		
//
//		if (annotations.size() == 0)
//			return 0;
//
//		int[] this_overlaps = new int[ann1.this_length];
//		int[] source_overlaps = new int[ann1.source_length];
//		
//		for (Annotation ann2 : annotations){ 
//			mark_overlapping_chars_sus(this_overlaps, ann1, ann2);
//			mark_overlapping_chars_src(source_overlaps, ann1, ann2);					
//		}
//		return Com.sumArray(this_overlaps) + Com.sumArray(source_overlaps) ;
//	}
//		
//	/**
//	 * Sets the i-th integer of the overlaps array (corresponding
//	 * to the suspicious fragment) to 1 
//	 * @param overlaps
//	 * @param ann1
//	 * @param ann2
//	 */
//	private void mark_overlapping_chars_sus(int[] overlaps, 
//										  Annotation ann1, 
//										  Annotation ann2 
//										  ){	
//		offset_difference = ann2.this_offset - ann1.this_offset;
//		overlap_start = Math.min(Math.max(0, offset_difference), ann1.this_length);
//		overlap_end = Math.min(Math.max(0, offset_difference + ann2.this_length), ann1.this_length);
//		for (int i=overlap_start; i< overlap_end; i++)
//			overlaps[i] = 1;
//	}
//	
//	/**
//	 * Sets the i-th integer of the overlaps array (corresponding
//	 * to the source fragment) to 1 
//	 * @param overlaps
//	 * @param ann1
//	 * @param ann2
//	 */
//	private void mark_overlapping_chars_src(int[] overlaps, Annotation ann1, 
//			  												  Annotation ann2 
//			  													){
//		offset_difference = ann2.source_offset - ann1.source_offset;
//		overlap_start = Math.min(Math.max(0, offset_difference), ann1.source_length);
//		overlap_end = Math.min(Math.max(0, offset_difference + ann2.source_length), 
//										ann1.source_length);
//		for (int i=overlap_start; i < overlap_end; i++)
//			overlaps[i] = 1;	 
//	}
//	
//	/**
//	 * Returns true iff ann2 overlaps ann1
//	 * @param ann1
//	 * @param ann2
//	 * @return
//	 */
//	private boolean is_overlapping(Annotation ann1, Annotation ann2){
//		fragment_detected = false;
//		
//		if (! ann1.suspicious_reference.equals(ann2.suspicious_reference))
//			return false;
//		
//		fragment_detected = 
//			     //ann1.suspicious_reference == ann2.suspicious_reference   &&
//				   (ann2.this_offset + ann2.this_length) > ann1.this_offset &&
//				   ann2.this_offset < (ann1.this_offset + ann1.this_length);
//	    if (ann1.intrinsic == false && ann2.intrinsic == false){
//	    	if (! ann1.source_reference.equals(ann2.source_reference))
//				return false;
//	    	
//	    	fragment_detected = fragment_detected && 
//	    				//ann1.source_reference == ann2.source_reference     &&
//                 	   (ann2.source_offset + ann2.source_length) > ann1.source_offset &&
//                       ann2.source_offset < (ann1.source_offset + ann1.source_length);
//	    }	    
//		return fragment_detected;
//	}
//	
//	/**
//	 * Returns a map with the suspicious document reference as
//	 * key and the entire annotation as value.
//	 * @param annotations
//	 * @return
//	 */
//	private Map<String, List<Annotation>> index_annotations(
//						List<Annotation> annotations){
//		Map<String, List<Annotation>> map = new HashMap<String, List<Annotation>>();
//		for (Annotation ann : annotations){
//			if (! map.containsKey(ann.suspicious_reference))
//					map.put(ann.suspicious_reference, new ArrayList<Annotation>());
//			map.get(ann.suspicious_reference).add(ann);
//		}
//		return map;
//	}
//
//	public static void main (String[] args) 
//			throws IOException, ParserConfigurationException, SAXException{
//		PerfMeasuresPAN pMeas = new PerfMeasuresPAN(false,  // onlySimulated
//											false, // onlyArtificial
//											false, // onlyCrossLanguage
//											false, // onlyExternal
//											true  // onlyIntrinsic
//											);
//		Reporter.report("BEGINNING OF THE PROCESS");
//		pMeas.extract_annotations_suspicious();
//		for (String part : participants){
//			pMeas.det_path = Configuration.getResPath() + FileIO.separator + part; 
//			pMeas.extract_annotations_detection();
//			double mAVrecall = pMeas.macro_avg_recall();
//			double granularity = pMeas.granularity();
//			System.out.println(part + "  :  " + mAVrecall + " " +granularity);
//		}
//		
//		
//		
//		Reporter.report("END OF THE PROCESS");
//	}	
}
