package evaluation;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.SAXException;

import common.Com;
import common.Configuration;
import corpusAnalysisOld.PanAnalisys;

import documents.AnnDocument.Annotation;
import documents.DetectionDocument;
import documents.EvalSuspiciousDetection;
import documents.SuspiciousDocument;
import documents.SuspiciousDocument.SuspiciousAnnotation;
import es.nlel.common.io.FileIO;
import es.nlel.common.report.Reporter;
import es.nlel.pan.xml.DetectionXMLreader;
import es.nlel.pan.xml.SuspiciousXMLreader;

/**
 * Plagiarism detection performance measures.
 * 
 * This program is based on perfmeasures.py, developed by Martin Potthast.
 * It implements measures macro average recall and granularity as 
 * described by the authors of [1]. 
 * <p>
 * The main difference to the Python implementations is that the Recall 
 * can be obtained for every case instead of only the global result (only
 * small modifications were required to get this values with the Python
 * implementation, but we decided to make a version in Java).
 * <p>
 * [1]  Martin Potthast, Benno Stein, Alberto Barron-Cedeno, and Paolo Rosso.
 *      An Evaluation Framework for Plagiarism Detection.
 *      In Proceedings of the 23rd International Conference on Computational
 *      Linguistics (COLING 2010), Beijing, China. August 2010. ACL.
 *      
 * @author albarron
 *
 */
public class PerfMeasures extends PanAnalisys{
	
	protected int report_control = 10000;
	protected List<Annotation> cases = new ArrayList<Annotation>();
	protected List<Annotation> detections;
	
	protected Map<String, List<Annotation>> case_index;
	protected Map<String, List<Annotation>> det_index;
	public String det_path;
	protected List<Double> detections_per_case = new ArrayList<Double>();	
	
	protected 	   EvalSuspiciousDetection    current_suspicious_detection;
	protected List<EvalSuspiciousDetection>      list_suspicious_detection;
	//Controllers
	private int counter;
	
	//local variables that are used in different methods
	private int offset_difference;
	private int overlap_start;
	private int overlap_end;
	private boolean fragment_detected;
	
	private boolean analyse_paraphrases;
	
	
	/**
	 * 
	 */
	public PerfMeasures(){		
		sReader = new SuspiciousXMLreader();
		dReader = new DetectionXMLreader();
	}	
	
	public PerfMeasures(Boolean analyse_paraphrases){
		this();
		this.analyse_paraphrases = analyse_paraphrases;		
	}
	
	
	/**
	 * Only simulated cases are going to be analysed
	 */
	public void onlySimulated(){
		Reporter.report("Analysing simulated only");
		processAll();
		simulated = true;
	}
	
	/**
	 * Only artificial cases are going to be analysed
	 */
	public void onlyArtificial(){
		Reporter.report("Analysing artificial only");
		processAll();
		artificial = true;
	}
	
	/**
	 * Only cross-language cases are going to be analysed
	 */
	public void onlyCrossLanguage(){
		Reporter.report("Analysing cross-language only");
		processAll();
		crossLanguage = true;
	}
	
	/**
	 * Only external cases are going to be analysed
	 */
	public void onlyExternal(){
		Reporter.report("Analysing external only");
		processAll();
		external = true;
	}
	
	/**
	 * Only intrinsic cases are going to be analysed
	 */
	public void onlyIntrinsic(){
		Reporter.report("Analysing intrinsic only");
		processAll();
		intrinsic = true;
	}
	
	/**
	 * Sets every kind of plagiarism as false. It is called
	 * by all the only... methods to guarantee that the rest are 
	 * false.
	 * 
	 * Can be called from outside in case of misconfiguration 
	 * to reset and consider all of the cases.
	 */
	public void processAll(){
		setAllPanFalse();
//		setAllParaphraseFalse();
	}
	
	private void setAllPanFalse(){
		simulated     = false;		artificial    = false;
		crossLanguage = false;		external      = false;
		intrinsic     = false;		
	}
	
//	//	related to paraphrases annotations
//	private void setAllParaphraseFalse(){
//		derivative_morpho_change  = false;		diathesis_syntax     	  = false;		
//		equals_others     		  = false;		flexive_morpho_change     = false;		
//		lex_pattern_semantic      = false;		no_paraphrase_others      = false;		
//		opposite_polarity_lexical = false;		same_polarity_lexical     = false;		
//		structure_discourse       = false;		synthetic_analytic_lexical= false;
//	}
	
	/**
	 * Gets the list of suspicion annotations.
	 * @return
	 */
	public List<Annotation> get_suspicious_list(){
		return cases;
	}
	
//	public List<Annotation> get_suspicious_list_translation(){
//		List<Annotation> tr_cases = new ArrayList<Annotation>();
//		for (Annotation ann : cases){
////			ann.
//		}
//		return null;
//		
//	}
//	
	
	/**
	 * Gets the list of detection annotations.
	 * @return
	 */
	public List<Annotation> get_detection_list(){
		return detections;
	}
	
	
	/**
	 * Charges the plagiarised fragment parameters into the global
	 * variable atts:
	 * 
	 * - plagiarism_reference
	 * - this_offset
	 * - this_length
	 * 
	 * @param ann
	 * @param id
	 */
	protected void chargetAttributesPlag (SuspiciousAnnotation ann, String id){
		atts.clear();
		//Suspicious fragment
		atts.addAttribute("","","plagiarism_reference", "CDATA", id);
		atts.addAttribute("","","this_offset", "CDATA", String.valueOf(ann.this_offset)); 
		atts.addAttribute("","","this_length", "CDATA", String.valueOf(ann.this_length));
				
		//Source fragment
		atts.addAttribute("","","source_reference", "CDATA", ann.source_reference);
		atts.addAttribute("","","this_offset", "CDATA", String.valueOf(ann.source_offset)); 
		atts.addAttribute("","","this_length", "CDATA", String.valueOf(ann.source_length));				
	}
	
	/**
	 * Iterates over the XML suspicious files in a 
	 * directory to load the annotations.
	 * 
	 * @throws ParserConfigurationException
	 * @throws SAXException
	 * @throws IOException
	 */
	public void extract_annotations_suspicious() 
		throws ParserConfigurationException, SAXException, IOException{
		counter = 1;
		List<String> xmlFiles;
		if (analyse_paraphrases)
			xmlFiles = FileIO.getSpecificFilesRecursively(
					new File(par_path), "suspicious", "xml");
		else
			xmlFiles = FileIO.getSpecificFilesRecursively(
					new File(ann_path), "suspicious", "xml");
				
		for (String f : xmlFiles){
			Reporter.reportIfModule(("Extracting plagiairsm cases from " + counter + " : " + f), counter++, report_control);
			update_suspicious((SuspiciousDocument) sReader.xml2AnnDoc(f));
		}		
		case_index = index_annotations(cases);		
		Reporter.report("Plagiarism cases extracted: " + cases.size());
	}	
	
	public void extract_annotations_suspicious(String dir) 
		throws ParserConfigurationException, SAXException, IOException{
		counter = 1;
		List<String> xmlFiles;
		xmlFiles = FileIO.getSpecificFilesRecursively(
					new File(dir), "suspicious", "xml");
				
		for (String f : xmlFiles){
			Reporter.reportIfModule(("Extracting plagiairsm cases from " + counter + " : " + f), counter++, report_control);
			update_suspicious((SuspiciousDocument) sReader.xml2AnnDoc(f));
		}		
		case_index = index_annotations(cases);		
		Reporter.report("Plagiarism cases extracted: " + cases.size());
	
	}
	
	/**
	 * If requested, keeps only a kind of plagiarism from the
	 * suspicious documents annotations: 
	 * intrinsic, external, artificial, simulated, cross.
	 * 
	 * @param sDocument
	 */
	public void update_suspicious(SuspiciousDocument sDocument){
		if (sDocument.contains_plagiarism == 0)	//the document does not contain plagiarism.
			return;
		
		if (intrinsic)
			sDocument.keepOnlyIntrinsic();
		else if (external)
			sDocument.keepOnlyExternal();
		else if (simulated)
			sDocument.keepOnlySimulated();
		else if (artificial)
			sDocument.keepOnlyArtificial();
		else if (crossLanguage)
			sDocument.keepOnlyCrossLanguage();
		
		if (sDocument.susp_annotations.size() > 0)
			cases.addAll(sDocument.susp_annotations);				
	}

	/**
	 * Iterates over the XML detection files in a 
	 * directory to import the annotations.
	 * 
	 * @throws ParserConfigurationException
	 * @throws SAXException
	 * @throws IOException
	 */
	public void extract_annotations_detection() 
		throws ParserConfigurationException, SAXException, IOException{
		detections = new ArrayList<Annotation>();
		counter = 1;	
		List<String> xmlFiles = FileIO.getSpecificFilesRecursively(
				new File(det_path), "suspicious", "xml");
		
		for (String f : xmlFiles){
			Reporter.reportIfModule(("Extracting detections from file " + counter), 
								counter++, report_control);			
			update_detection((DetectionDocument) dReader.xml2AnnDoc(f));
		}		
		det_index = new	HashMap<String, List<Annotation>>();	//	CREO QUE AQUI ESTA EL ERROR 
		det_index  = index_annotations(detections);		
		Reporter.report("Detections extracted: " + detections.size());
	}
	
	/**
	 * Adds the new detections of this document information to the 
	 * collection of detections
	 * @param dDocument
	 */
	private void update_detection(DetectionDocument dDocument){
		if (dDocument.annotations.size() > 0)
			detections.addAll(dDocument.annotations);
	}
	
	/**
	 * Granularity of the detections
	 * @return
	 */
	public double granularity(){
		if (detections.size() == 0)
	        return 1;
		
		double num_dets = 0;
		double detected_cases = 0;
		counter = 1;
		
		//pending determine whether some of this should be taken
		//to another method in a way that it could be called 
		//from outside to get the granularity per case.
		detections_per_case.clear();
		for (String susp_reference : case_index.keySet()){
			Reporter.reportIfModule(("Recall for case " + counter), counter++, report_control);
			if (! det_index.containsKey(susp_reference))
				continue;
			List<Annotation> this_detections = det_index.get(susp_reference);
			
			for (Annotation eCase : case_index.get(susp_reference)){
				num_dets = 0;
				for (Annotation det : this_detections)
					if (is_overlapping(eCase, det))			num_dets++;						
				detections_per_case.add(num_dets);
			}			
		}
		
		for (Double n_dets : detections_per_case)			
			if (n_dets > 0)				detected_cases ++;			
			
		if (detected_cases == 0)
	        return 1;
	    return Com.sumList(detections_per_case) / detected_cases;	    
	}
	
	/**
	 * Macro average recall for the detections.
	 * 
	 * @return
	 */
	public double macro_avg_recall(){		
		int num_cases = cases.size();
		counter = 1;
		
		List<Double> recall_per_case = new ArrayList<Double>();
		for (String susp_reference : case_index.keySet()){
			
			if (! det_index.containsKey(susp_reference))
				continue;
			for (Annotation case_ann : case_index.get(susp_reference)){
				 recall_per_case.add( case_recall(case_ann, detections) );
				 Reporter.report("Recall for suspicious "+ case_ann.suspicious_reference  
						 		+ "\t this_offset "		 + case_ann.this_offset 
						 		+ "\t source " 			 + case_ann.source_reference + "\t" 
						 		+ "\t source_offset  "   + case_ann.source_offset 
						 		+"\t recall "	 		 + case_recall(case_ann, detections) );
			}
		}
		return Com.sumList(recall_per_case) / num_cases;
	}	
	
	/**
	 * Calculates recall for a given suspicious text fragment and the 
	 * corresponding detections.
	 *  
	 * @param suspicious
	 * @param detections
	 * @return
	 */
	public double case_recall(Annotation suspicious, List<Annotation> detections){
		
		//We initialise it every time in order to get the cases  
		//of the current gold standard annotation only
		list_suspicious_detection = new ArrayList<EvalSuspiciousDetection>(); 
		
		double num_detected_plagiarized = overlapping_chars(suspicious, detections);
		double num_plagiarized = suspicious.this_length + suspicious.source_length;
		
		if (num_detected_plagiarized != 0){
			update_current_recall(num_detected_plagiarized / num_plagiarized);
			list_suspicious_detection.add(current_suspicious_detection);
		}
		return num_detected_plagiarized / num_plagiarized;		
	}
	
	/**
	 * Returns the number of characters in ann1 that overlaps with
	 * the annotation sin the detections list.
	 * 
	 * @param ann1
	 * @param detections
	 * @return
	 */
	private int overlapping_chars(Annotation ann1, List<Annotation> detections){		
		List<Annotation> overlapping_detections = new ArrayList<Annotation>();

		for (Annotation detection : detections)
			if (is_overlapping(ann1, detection))
				overlapping_detections.add(detection);		

		if (overlapping_detections.size() == 0)
			return 0;

		int[] this_overlaps = new int[ann1.this_length];
		int[] source_overlaps = new int[ann1.source_length];
	
		for (Annotation detection : overlapping_detections){ 
			mark_overlapping_chars_sus(this_overlaps, ann1, detection);			
			mark_overlapping_chars_src(source_overlaps, ann1, detection);
			
			update_current_suspicious_detection(ann1, detection);			
		}		
		return Com.sumArray(this_overlaps) + Com.sumArray(source_overlaps) ;
	}
	
	/**
	 * It assigns to the variable current_suspicious_detection the identifiers,
	 * offsets and lengths corresponding to the currently analysed pair of text fragments.
	 * The only element that it does not update is recall.
	 * @param gold
	 * @param detection
	 */
	private void update_current_suspicious_detection(Annotation gold, Annotation detection){
		current_suspicious_detection = new EvalSuspiciousDetection();
		
		current_suspicious_detection.suspicious_reference = gold.suspicious_reference;
		current_suspicious_detection.source_reference	  = gold.source_reference;
		current_suspicious_detection.this_offset 		  = gold.this_offset; 
		current_suspicious_detection.this_length 		  = gold.this_length; 
		current_suspicious_detection.source_offset 		  = gold.source_offset;
		current_suspicious_detection.source_length 		  = gold.source_length;
		
		current_suspicious_detection.det_this_offset 	  = detection.this_offset;
		current_suspicious_detection.det_this_length 	  = detection.this_length;
		current_suspicious_detection.det_source_offset 	  = detection.source_offset;
		current_suspicious_detection.det_source_length 	  = detection.source_length;
	}
	
	private void update_current_recall(double curr_recall){
		current_suspicious_detection.recall = curr_recall;
	}
	
	
	public List<EvalSuspiciousDetection> get_list_suspicious_detection(){
		return list_suspicious_detection;
	}
	
	/**
	 * Sets the i-th integer of the overlaps array (corresponding
	 * to the suspicious fragment) to 1.
	 * 
	 * @param overlaps
	 * @param ann1
	 * @param ann2
	 * @return offsets for start and end overlapping characters 
	 */
	private int[] mark_overlapping_chars_sus(int[] overlaps, 
										  Annotation ann1, 
										  Annotation ann2 
										  ){
		int[] overlap_start_end = new int[2];
		
		offset_difference = ann2.this_offset - ann1.this_offset;
		overlap_start = Math.min(
								Math.max(0, offset_difference), 	ann1.this_length);
		overlap_end = Math.min(
								Math.max(0, offset_difference + ann2.this_length), 		ann1.this_length);
		
		//we obtain the start and end overlap values
		overlap_start_end[0] = ann1.this_offset + overlap_start;
		overlap_start_end[1] = ann1.this_offset + overlap_end;
		
		for (int i=overlap_start; i< overlap_end; i++)
			overlaps[i] = 1;		
		
		return overlap_start_end;
	}
	
	/**
	 * Sets the i-th integer of the overlaps array (corresponding
	 * to the source fragment) to 1 
	 * @param overlaps
	 * @param ann1
	 * @param ann2
	 * @return offsets for start and end overlapping characters 
	 */
	private int[] mark_overlapping_chars_src(int[] overlaps, Annotation ann1, 
			  												  Annotation ann2 
			  													){
		int[] overlap_start_end = new int[2];
		                                  
		offset_difference = ann2.source_offset - ann1.source_offset;
		overlap_start = Math.min(
								Math.max(0, offset_difference), ann1.source_length);
		overlap_end = Math.min(
								Math.max(0, offset_difference + ann2.source_length),	ann1.source_length);
		
		//we obtain the start and end overlap values
		overlap_start_end[0] = ann1.source_offset + overlap_start;
		overlap_start_end[1] = ann1.source_offset + overlap_end;
		
		for (int i=overlap_start; i < overlap_end; i++)
			overlaps[i] = 1;
		
		return overlap_start_end;
	}
	
	/**
	 * Returns true iff ann2 overlaps ann1
	 * @param ann1
	 * @param ann2
	 * @return
	 */
	private boolean is_overlapping(Annotation ann1, Annotation ann2){
		fragment_detected = false;
		
		if (! ann1.suspicious_reference.equals(ann2.suspicious_reference))
			return false;
		
		fragment_detected = 
			     //ann1.suspicious_reference == ann2.suspicious_reference   &&
				   (ann2.this_offset + ann2.this_length) > ann1.this_offset &&
				   ann2.this_offset < (ann1.this_offset + ann1.this_length);
	    if (ann1.intrinsic == false && ann2.intrinsic == false){
	    	if (! ann1.source_reference.equals(ann2.source_reference))
				return false;
	    	
	    	fragment_detected = fragment_detected && 
	    				//ann1.source_reference == ann2.source_reference     &&
                 	   (ann2.source_offset + ann2.source_length) > ann1.source_offset &&
                       ann2.source_offset < (ann1.source_offset + ann1.source_length);
	    }	    
		return fragment_detected;
	}
	
	/**
	 * Returns a map with the suspicious document reference as
	 * key and the entire annotation as value.
	 * @param annotations
	 * @return
	 */
	private Map<String, List<Annotation>> index_annotations(
						List<Annotation> annotations){
		Map<String, List<Annotation>> map = new HashMap<String, List<Annotation>>();
		for (Annotation ann : annotations){
			if (! map.containsKey(ann.suspicious_reference))
					map.put(ann.suspicious_reference, new ArrayList<Annotation>());
			map.get(ann.suspicious_reference).add(ann);
		}
		return map;
	}

	public static void main (String[] args) 
			throws IOException, ParserConfigurationException, SAXException{
		PerfMeasures pMeas = new PerfMeasures(false);
//		PerfMeasures pMeas = new PerfMeasures(true);	//we want paraphrases
		
//		pMeas.onlySimulated();  	// onlySimulated
//		pMeas.onlyArtificial(); 	// onlyArtificial
//		pMeas.onlyCrossLanguage();	// onlyCrossLanguage
//		pMeas.onlyExternal();		// onlyExternal
//		pMeas.onlyIntrinsic();		// onlyIntrinsic
		
		
//		pMeas.only_derivative_morpho_change();
//		pMeas.only_diathesis_syntax();
//		pMeas.only_equals_others();
//		pMeas.only_flexive_morpho_change();
//		pMeas.only_lex_pattern_semantic();
//		pMeas.only_no_paraphrase_others();
//		pMeas.only_opposite_polarity_lexical();
//		pMeas.only_same_polarity_lexical();
//		pMeas.only_structure_discourse();
//		pMeas.only_synthetic_analytic_lexical();
		
									
		Reporter.report("BEGINNING OF THE PROCESS");
		pMeas.extract_annotations_suspicious();
		for (String part : participants){
			pMeas.det_path = Configuration.getDetectionPath() + FileIO.separator + part; 
			pMeas.extract_annotations_detection();
//			pMeas.addRandomOriginalDocuments();
			double mAVrecall = pMeas.macro_avg_recall();
			double granularity = pMeas.granularity();
			System.out.println(part + "  :  " + mAVrecall + " " +granularity);
		}		
		Reporter.report("END OF THE PROCESS");
	}	
}
